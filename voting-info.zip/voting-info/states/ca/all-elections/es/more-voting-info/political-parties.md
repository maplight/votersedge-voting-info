---
title: "Political Parties"
published: true
weight: 5
section: more-voting-info
priority: "Minor"
---
--