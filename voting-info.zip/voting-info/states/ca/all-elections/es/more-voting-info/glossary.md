---
title: "Glossary"
published: true
weight: 4
section: more-voting-info
priority: "Minor"
---
--