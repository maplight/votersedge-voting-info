---
title: "Evaluating California budget and taxes"
published: true
weight: 7
section: more-voting-info
priority: "Minor"
---
--