---
title: "Evaluating State Ballot Measures"
published: true
weight: 6
section: more-voting-info
priority: "Minor"
---
--