---
title: "How do I vote at the polling place in person?  "
published: true
weight: 5
section: ways-to-vote
priority: "Minor"
---