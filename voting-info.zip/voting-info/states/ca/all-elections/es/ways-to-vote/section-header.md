---
title: "Ways to Vote?"
published: true
weight: 7
section: ways-to-vote
priority: "Major"
---
There are 3 Ways to Vote 
  