---
title: "When do I vote?"
published: true
weight: 3
section: important-dates-deadlines
priority: "Minor"
---