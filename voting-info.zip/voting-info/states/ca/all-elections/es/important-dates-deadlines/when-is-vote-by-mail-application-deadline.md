---
title: "When is vote by mail application deadline?"
published: true
weight: 2
section: important-dates-deadlines
priority: "Minor"
---