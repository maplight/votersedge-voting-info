---
title: "When is voter registration deadline?"
published: true
weight: 1
section: important-dates-deadlines
priority: "Minor"
---