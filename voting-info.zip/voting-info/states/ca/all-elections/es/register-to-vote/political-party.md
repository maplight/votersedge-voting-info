---
title: "Do I have to register as a member of a political party?"
published: true
weight: 4
section: register-to-vote
priority: "Minor"
---
You may either register as a member of a political party (Republican, Democratic, Green, etc.) or you may choose not to state a party preference. Your choice between registering as a party member or as a no-party-preference voter may affect whether or not you’re allowed to vote in a primary election to choose a candidate to run for a political party in the general election.