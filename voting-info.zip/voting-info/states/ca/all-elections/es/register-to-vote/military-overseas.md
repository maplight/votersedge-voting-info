---
title: "What if I am in the military and overseas voter, or I live abroad?"
published: true
weight: 0
section: register-to-vote
priority: "Minor"
---
Military and overseas voters are United States citizens who are members of the Uniformed Services (on active duty) and their eligible dependents, members of the Merchant Marine and their eligible dependents, commissioned corps of the Public Health Service, commissioned corps of the National Oceanic and Atmospheric Administration, or United States citizens residing outside the United States. To apply to register to vote, receive your elections materials, and vote, you must apply for a special absentee ballot by filling out the Federal Post Card Application (FPCA).