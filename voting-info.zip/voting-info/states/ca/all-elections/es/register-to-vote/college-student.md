---
title: "What if I am a college student?"
published: true
weight: 8
section: register-to-vote
priority: "Minor"
---
As a Californian living away from home while attending a college, trade school or technical school, you may choose to register to vote using either the home away from home address you use while at school, or your traditional home address.

Choosing which address to use when you register to vote is a personal decision. Whatever you decide, you may not register to vote in two places during the same election cycle.
