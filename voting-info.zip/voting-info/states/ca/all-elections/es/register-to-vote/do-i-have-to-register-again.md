---
title: "Do I have to register again if I already registered to vote?"
published: true
weight: 3
section: register-to-vote
priority: "Minor"
---
You must reregister if you:

- move your address
- change your name 
- wish to change political party affiliation 
- were removed from the registration rolls while in prison or on parole for the conviction of a felony
