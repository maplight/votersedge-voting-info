---
title: "What is a permanent vote-by-mail voter?"
published: true
weight: 5
section: register-to-vote
priority: "Minor"
---
When you register you will have the option to have vote by mail ballots automatically sent to you for every election.  If you are already registered, you may also contact your County Elections Office to ask how to change your status to be a permanent vote-by-mail voter.
