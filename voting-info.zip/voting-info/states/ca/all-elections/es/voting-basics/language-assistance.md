The California Secretary of State's online application is available in English, Spanish, Chinese, Hindi, Japanese, Khmer, Korean, Tagalog, Thai, and Vietnamese. To register in one of these languages please select your language below.
 
Español  Spanish
中文  Chinese
हिन्दी  Hindi
日本語  Japanese
ខ្មែរ  Khmer
한국어  Korean
Tagalog
ภาษาไทย  Thai
Tiếng Việt  Vietnamese