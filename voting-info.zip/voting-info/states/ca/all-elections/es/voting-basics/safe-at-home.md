What if sharing my address could put me in a life-threatening situation?

You may qualify for the Safe At Home confidential address program. Please do not apply to register to vote using the online site. Contact the Safe At Home program toll-free at (877) 322-5227 or by the Safe At Home email.