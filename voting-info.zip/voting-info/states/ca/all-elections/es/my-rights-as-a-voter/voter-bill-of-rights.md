---
title: "Voter Bill of Rights "
published: true
weight: 1
section: my-rights-as-a-voter
priority: "Minor"
---
