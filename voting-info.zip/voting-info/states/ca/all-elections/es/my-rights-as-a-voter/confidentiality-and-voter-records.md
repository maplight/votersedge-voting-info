---
title: "Confidentiality and voter records"
published: true
weight: 5
section: my-rights-as-a-voter
priority: "Minor"
---
