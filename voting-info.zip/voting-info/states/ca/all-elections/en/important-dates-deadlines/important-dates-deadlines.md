---
title: Important Dates and Deadlines
published: true
weight: 1
section: "important-dates-deadlines"
priority: "Major"
---
There are some important dates and deadlines for California voters to know.