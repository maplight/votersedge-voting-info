---
title: "When is vote by mail application deadline?"
published: true
weight: 3
section: "important-dates-deadlines"
priority: "Minor"
---
For every election, your vote-by-mail request must be received in the county elections office **no later than 7 days before an election by 5 PM.**  

For detailed information check [How do I vote by mail?](#item-vote-by-mail)
