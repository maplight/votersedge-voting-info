---
title: "Ways to Vote"
published: true
weight: 1
section: "ways-to-vote"
priority: "Major"
---
**There are a number of ways to vote in California. You may vote**:  

**By mail**   

**Early in person** at designated places in your county  
Sometimes these early vote locations are available on Election Day too.  

**At the polling place** in person on Election Day

