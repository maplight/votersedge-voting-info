---
title: "How do I return my vote-by-mail ballot?"
published: false
weight: 4
section: "ways-to-vote"
priority: "Minor"
---
**Return the ballot:**
1. **By mail** **or**
2. **Drop it off** at a location designated by your county **or**
3. **Drop it off** at any polling place in your county by 8 pm on Election Day.

**If you mail your ballot back, don’t delay.**  

Your completed vote-by-mail ballot must be **postmarked** on or before **[INSERT Day, Month Date, Year]**

Once mailed and postmarked, the ballot must be **received** by the elections office no later than 3 days after Election Day. For this election that date is **[INSERT Day, Month Date, Year]**
