---
title: "How do I vote early in person?"
published: true
weight: 5
section: "ways-to-vote"
priority: "Minor"
---
You may vote in person either at your [County Elections Office](#section-election-office-contact) or at another early voting location before Election Day. Some early voting locations are also open through Election Day.
