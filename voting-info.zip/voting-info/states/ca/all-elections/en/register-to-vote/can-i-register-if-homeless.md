---
title: "Can I register if I am homeless?"
published: true
weight: 13
section: "register-to-vote"
priority: "Minor"
---
**Yes, you can register if you are homeless if**:  
- You have a fixed location where you can be assigned to a voting precinct. You must describe your location using cross streets, landmarks, or other information to explain where you live.  
- **AND** you have a place where you can receive mail, such as a post office box or homeless shelter.
