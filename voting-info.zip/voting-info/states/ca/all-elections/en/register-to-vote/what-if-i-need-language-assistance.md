---
title: "What if I need language assistance?"
published: true
weight: 6
section: "register-to-vote"
priority: "Minor"
---
The California Secretary of State's [online application](http://www.sos.ca.gov/elections/voter-registration/) is available in English, Spanish, Chinese, Hindi, Japanese, Khmer, Korean, Tagalog, Thai, and Vietnamese. To register in one of these languages please select your language below.  

[Español Spanish](http://registertovote.ca.gov/es/)       
[中文 Chinese](http://registertovote.ca.gov/zh/)     
[हिन्दी Hindi](http://registertovote.ca.gov/hi/)    
[日本語 Japanese](http://registertovote.ca.gov/ja/)  
[ខ្មែរ Khmer](http://registertovote.ca.gov/km)  
[한국어 Korean](http://registertovote.ca.gov/ko/)  
[Tagalog](http://registertovote.ca.gov/tl/)   
[ภาษาไทย Thai](http://registertovote.ca.gov/th/)   
[Tiếng Việt Vietnamese](http://registertovote.ca.gov/vi/)  
