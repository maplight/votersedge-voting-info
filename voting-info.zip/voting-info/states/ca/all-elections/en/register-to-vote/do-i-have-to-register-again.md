---
title: "Once I am registered to vote do I ever have to register again?"
published: true
weight: 9
section: "register-to-vote"
priority: "Minor"
---
**You must re-register if you**:  
- Move to a different address.  
- Change your name.  
- Wish to change political parties or to state no party preference.  
- Were removed from the registration rolls while in prison or on parole for the conviction of a felony.  
