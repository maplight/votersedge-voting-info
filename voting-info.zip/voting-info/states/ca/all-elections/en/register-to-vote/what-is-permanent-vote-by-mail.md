---
title: "What is a permanent vote-by-mail voter?"
published: true
weight: 8
section: "register-to-vote"
priority: "Minor"
---
When you register you can choose to have vote-by-mail ballots (“absentee” ballots) automatically sent to you for every election.   

If you are already registered, you may also contact your [county elections office](#section-election-office-contact) to change your status to be a permanent vote-by-mail voter.  

Check [How do I vote by mail?](#item-vote-by-mail) for more information.
