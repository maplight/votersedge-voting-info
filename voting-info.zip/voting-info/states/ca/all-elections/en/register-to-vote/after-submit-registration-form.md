---
title: "What happens after I submit my registration form?"
published: true
weight: 5
section: "register-to-vote"
priority: "Minor"
---
If time permits, your county elections official will contact you when your voter registration application is approved or if more information is needed to confirm your eligibility.   

You can check with your county elections office to make sure you’re registered. [Check the status of your voter registration.](http://www.sos.ca.gov/elections/registration-status/)