---
title: "How California primary elections work: Top-Two explanation"
published: false
weight: 11
section: "voting-basics"
priority: "Minor"
---
**All voters can vote in the primary election.**  
- A primary election in June chooses the candidates who will run in the General Election in November  
- You may see three different types of primaries on your ballot.  

**The way each primary works depends on the office.**  

