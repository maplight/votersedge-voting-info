---
title: "What is a special election?"
published: true
weight: 15
section: "voting-basics"
priority: "Minor"
---

A special election happens when an elected official has left their office before the end of their terms.  This usually happens when the official dies or has resigned from the office.
