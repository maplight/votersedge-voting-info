---
title: "What if I am not on the list of voters at my polling place?  "
published: true
weight: 3
section: "voting-basics"
priority: "Minor"
---
If your name is not on the list of registered voters at your polling place you have the right to cast a [provisional ballot](#item-what-is-provisional-ballot).
