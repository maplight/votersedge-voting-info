---
title: "What is a recall election?"
published: true
weight: 16
section: "voting-basics"
priority: "Minor"
---
A recall election decides if an elected official is removed from their job and who will replace that official.  

For more information visit [recall elections](http://www.sos.ca.gov/elections/prior-elections/statewide-election-results/statewide-special-election-october-7-2003/frequently-asked-questions/#1).  
