---
title: "Why am I in a mail-only precinct?"
published: true
weight: 10
section: "voting-basics"
priority: "Minor"
---
Voters who live in precincts with 250 or fewer registered voters may receive vote-by-mail ballots and not have the option to vote in person at the polls on Election Day.  

Check [How do I vote by mail?](#item-vote-by-mail) for directions.
