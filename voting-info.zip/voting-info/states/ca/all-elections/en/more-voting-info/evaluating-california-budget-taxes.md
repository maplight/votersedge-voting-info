---
title: Evaluating California budget and taxes
published: true
weight: 5
section: "more-voting-info"
priority: "Minor"
---

Visit [Fast Facts: State Taxes and Budget](http://www.easyvoterguide.org/wp-content/uploads/2011/08/FastFacts-BallotMeasures-v2.pdf).
