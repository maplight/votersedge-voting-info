---
title: "How do I find out what political districts I live in?"
published: true
weight: 3
section: "more-voting-info"
priority: "Minor"
---
For information on State legislative districts and U.S. Congressional Offices, visit the [California Secretary of State](http://www.sos.ca.gov/elections/additional-elections-information/who-are-my-representatives/).  

For information on your city, county, and other local offices contact your [county elections office](#section-election-office-contact).  
