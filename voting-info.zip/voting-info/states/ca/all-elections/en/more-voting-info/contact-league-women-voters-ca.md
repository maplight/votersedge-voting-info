---
title: Contact the League of Women Voters of California Education Fund
published: true
weight: 9
section: "more-voting-info"
priority: "Minor"
---

Contact the [League of Women Voters California Education Fund](https://cavotes.org/) for more helpful election information.   
