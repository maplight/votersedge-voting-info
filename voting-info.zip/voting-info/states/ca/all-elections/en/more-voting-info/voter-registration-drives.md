---
title: Voter Registration Drives
published: true
weight: 7
section: "more-voting-info"
priority: "Minor"
---
Visit the California Secretary of State's [Guide to Voter Registration Drives.](http://www.sos.ca.gov/elections/additional-elections-information/publications-and-resources/guide-vr-drives/)
