---
title: "How Do I Vote by Mail?"
published: true
weight: 1
section: how-to-vote
priority: "Minor"
---

Vote by mail

Request a vote-by-mail ballot from your County Elections Office.  

Make sure that you send in your request so that it’s received by the Elections Office no later than 7 days before the election by 5 PM. 

Follow the directions to fill out your ballot and don’t forget to sign & seal the special envelope provided. You can return the ballot:
• By mail 
• Drop it off at a location designated by your county 
• Drop it off at any polling place in your county by 8 pm on Election Day.

If you mail it back don’t delay! Mailed ballots must be sent before or on Election Day and the Elections Office must receive it no later than 3 days after Election Day.
 
