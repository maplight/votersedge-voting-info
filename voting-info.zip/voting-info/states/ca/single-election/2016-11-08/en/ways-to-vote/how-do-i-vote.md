---
title: "How do I vote?"
published: true
weight: 7
section: how-to-vote
priority: "Major"
---
There are 3 Ways to Vote 
  