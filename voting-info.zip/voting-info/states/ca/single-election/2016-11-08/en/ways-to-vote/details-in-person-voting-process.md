---
title: "Details on the in-person voting process"
published: true
weight: 0
section: how-to-vote
priority: "Minor"
---
