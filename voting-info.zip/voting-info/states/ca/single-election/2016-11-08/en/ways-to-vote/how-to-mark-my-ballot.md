---
title: "How to mark my ballot"
published: true
weight: 0
section: how-to-vote
priority: "Minor"
---

  