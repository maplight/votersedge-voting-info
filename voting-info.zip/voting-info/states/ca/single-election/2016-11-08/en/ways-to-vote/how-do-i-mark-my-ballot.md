---
title: "How Do I Mark my Ballot?"
published: true
weight: 4
section: how-to-vote
priority: "Minor"
---
How do I mark my ballot in the polling place?

                 
 2. Mark Ballot                  

         


How do I mark my vote-by-mail ballot?
Follow the instructions provided with your vote-by-mail ballot.  
1.  Mark the vote-by-mail ballot in the manner instructed above for polling place ballots.  
2.  Place the vote-by-mail ballot in the special envelope provided by your county’s election office.  
3.  Don’t forget to fill out the required information on the envelope, seal, and SIGN the back of the envelope!
4.  If a postage stamp is required then make sure that you put appropriate postage amount on the envelope.
