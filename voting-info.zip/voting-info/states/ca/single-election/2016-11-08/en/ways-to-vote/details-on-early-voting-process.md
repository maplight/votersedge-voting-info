---
title: "Details on the early voting process"
published: true
weight: 0
section: how-to-vote
priority: "Minor"
---
