---
title: "When do I vote?"
published: true
weight: 2
section: important-dates-deadlines
priority: "Minor"
---
When do I vote?

Early either by mail or in person: Monday, October 6 through Monday, November 3 
Early voting always starts 29 days before Election Day.

Election Day, Tuesday November 4. 2014 from 7 a.m. to 8 p.m.

For detailed information as to how to vote early or on Election Day, go to How Do I Vote. 
