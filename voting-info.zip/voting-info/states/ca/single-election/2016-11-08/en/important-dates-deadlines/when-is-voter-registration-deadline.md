---
title: "When is the Registration Deadline?"
published: true
weight: 0
section: important-dates-deadlines
priority: "Minor"
---

When is the voter registration deadline?

Monday, October 20 is the voter registration application deadline for this election.

Your voter registration application must be filled out completely and be submitted online, postmarked or hand-delivered to your county elections office at least 15 days before the election.  If you miss the deadline your application will still be processed and if approved, you will be able to vote in future elections.

You can check with your county election office to make sure you’re registered. Find county contact information here: Check Status of Your Voter Registration.

For detailed information on registration, go to Register to Vote. 

