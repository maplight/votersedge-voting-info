---
title: "When is the Vote-by-Mail Application Deadline?"
published: true
weight: 1
section: important-dates-deadlines
priority: "Minor"
---

When is the vote-by-mail application deadline?

Monday, October 28 at 5 p.m. is the vote-by-mail application deadline for this election.

For every election, your vote-by-mail request must be received in the county elections office no later than 7 days before an election by 5 p.m.

For detailed information on vote-by-mail, go to How Do I Vote by Mail? 

