---
title: "What if my address changes?"
published: true
weight: 0
section: register-to-vote
priority: "Minor"
---
