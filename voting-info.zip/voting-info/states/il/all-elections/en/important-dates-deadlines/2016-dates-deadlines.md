---
title: 2016 Election Dates and Deadlines
published: true
weight: 7
section: "important-dates-deadlines"
priority: "Minor"
---
**Primary Election - March 15, 2016**  
- Last day to register to vote: February 16, 2016  
- Grace Period Registration:  
	- First Day: February 17, 2016  
    - Last Day: March 14, 2016  
- Early Voting Period:  
	- First Day: February 4, 2016  
    - Last Day: March 14, 2016  

**General Election - November 8, 2016**  
- Last day to register to vote: October 11, 2016  
- Grace Period Registration:  
	- First Day: October 12, 2016
    - Last Day: November 8, 2016
- Early Voting Period:  
	- First Day: September 29, 2016
    - Last Day: November 7, 2016  


