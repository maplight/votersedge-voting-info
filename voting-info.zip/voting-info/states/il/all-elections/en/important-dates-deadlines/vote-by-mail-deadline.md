---
title: Vote-By-Mail Deadline
published: true
weight: 5
section: "important-dates-deadlines"
priority: "Minor"
---
You may **return your completed vote-by-mail ballot by mail** no more than 40 days prior to Election Day, and it must be postmarked no later than Election Day and received by the election authority no later than 14 days after the election.  

You may also **return your completed vote-by-mail ballot in person** to the election authority no more than 40 days prior to the election or on Election Day.  
