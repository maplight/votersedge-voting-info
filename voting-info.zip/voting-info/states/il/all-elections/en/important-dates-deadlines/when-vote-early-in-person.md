---
title: Early Voting Period
published: true
weight: 6
section: "important-dates-deadlines"
priority: "Minor"
---
You may vote early in person no more than 40 days prior to Election Day.
