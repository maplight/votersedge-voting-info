---
title: Voter Registration Deadlines
published: true
weight: 2
section: "important-dates-deadlines"
priority: "Minor"
---
Regular voter registration must be completed at least 27 days before the election or, if you want to register for the following election, at least 2 days after Election Day.  
