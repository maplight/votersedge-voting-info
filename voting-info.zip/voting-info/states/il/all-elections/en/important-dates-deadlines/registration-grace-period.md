---
title: Voter Registration Grace Period
published: true
weight: 3
section: "important-dates-deadlines"
priority: "Minor"
---
You may register to vote after the regular registration deadline, from the 27th day prior to an election all the way up to Election Day. However, grace period registration is only available if you register in person.  
