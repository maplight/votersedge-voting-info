---
title: Important Dates and Deadlines
published: true
weight: 1
section: "important-dates-deadlines"
priority: "Major"
---

There are some important dates and deadlines for Illinois voters to know, including when elections are held in the state.  

**Regular primary elections** are held on the third Tuesday in March in even-numbered years. **Regular general elections** are held on the first Tuesday in November in even-numbered years. In odd-numbered years, some jurisdictions have primary elections on the last Tuesday in February, and all jurisdictions have general elections on the first Tuesday of April.
