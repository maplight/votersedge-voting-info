---
title: "Do I need to declare a political party when I register to vote?"
published: true
weight: 4
section: "more-voting-info"
priority: "Minor"
---

**You do not need to declare a political party affiliation when you register to vote** in the state of Illinois in order to vote in party primaries.  

When you apply for a primary election ballot (either in person at the election authority office, at your polling place, or by mail), you will be asked to specify the political party in whose primary you wish to vote and the election official will give you the appropriate ballot.
