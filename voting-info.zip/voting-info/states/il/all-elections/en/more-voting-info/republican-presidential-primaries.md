---
title: Special note on Republican presidential primaries
published: true
weight: 6
section: "more-voting-info"
priority: "Minor"
---
**Republican primary voters vote not only for their presidential preference, but also for delegates and alternate delegates to the Republican National Convention.**  

Delegates and alternate delegates do not appear on Voter’s Edge, but they will appear on the Republican primary ballot. **Each voter may vote for up to three delegates and three alternate delegates.** Delegates and alternate delegates state on the ballot which candidate they support and they are bound to that candidate. The winner of the statewide presidential preference vote is awarded Illinois’s 12 at-large delegates.  
