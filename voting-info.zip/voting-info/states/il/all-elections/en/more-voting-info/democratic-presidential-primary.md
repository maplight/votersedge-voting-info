---
title: "Special note on Democratic presidential primaries"
published: true
weight: 7
section: "more-voting-info"
priority: "Minor"
---
**Democratic primary voters vote not only for their presidential preference, but also for 102 of Illinois's 181 delegates to the Democratic National Convention.**  

Delegates do not appear on Voter’s Edge, but they will appear on the Democratic primary ballot. Delegates state on the ballot which candidate they support, but they are not bound to that candidate. Instead, they are awarded to candidates proportionally based on the results of the presidential preference vote; presidential candidates must earn at least 15% of the preference vote to be awarded any delegates.  

The remainder of Illinois's Democratic delegates are apportioned as follows: 20 are pledged party leaders and elected officials selected by the state delegation, 34 are pledged at-large delegates (as well as 13 at-large alternates) also selected by the state delegation, and 25 are unpledged party leaders and elected officials.  
