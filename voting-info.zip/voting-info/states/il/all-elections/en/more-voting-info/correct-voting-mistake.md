---
title: How do I correct a voting mistake?
published: true
weight: 2
section: "more-voting-info"
priority: "Minor"
---
If you make a mistake, make a stray mark, or damage your ballot when voting in person, you may return your ballot to the election judges and receive a new one.  
