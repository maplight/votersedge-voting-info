---
title: "How do I know which political districts I live in?"
published: true
weight: 5
section: "more-voting-info"
priority: "Minor"
---

For information about the state legislative and judicial districts and U.S. congressional district where you live, visit the Illinois State Board of Elections’ [District/Official search tool](http://www.elections.il.gov/DistrictLocator/DistrictOfficialSearchByAddress.aspx).  

If you have further questions about your local political districts, the Board of Elections recommends that you contact your [local election authority](http://www.elections.il.gov/ElectionAuthorities/ElecAuthorityList.aspx?Selected=Election%20Authorities).
