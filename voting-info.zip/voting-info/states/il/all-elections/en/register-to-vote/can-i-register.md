---
title: "Can I register to vote?"
published: true
weight: 1
section: "register-to-vote"
priority: "Minor"
---
To register to vote in Illinois:  
- You must be a United States Citizen.  
- You must be 17 years old on or before the date of the Primary Election and turn 18 on or before the date of the General Election.  
- You must live in your election precinct at least 30 days prior to Election Day.  
- You must not be convicted and in jail.  
- You must not claim the right to vote anywhere else.  

