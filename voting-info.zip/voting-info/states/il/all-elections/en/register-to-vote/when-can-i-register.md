---
title: "When can I register to vote?"
published: true
weight: 3
section: "register-to-vote"
priority: "Minor"
---
**Regular voter registration** is open year-round, except during the 27-day period just prior to an election and during the 2-day period after each election (1 day after in Chicago).  

**Grace period registration** is an extension of the regular registration deadline from the 27th day prior to an election all the way up to Election Day. However, grace period registration is only available if you register in person.  
