---
title: "Do I need Voter ID?"
published: true
weight: 1
section: "voting-basics"
priority: "Minor"
---
**You do not need identification to vote in Illinois** unless you did not provide adequate identification when you registered to vote by mail and this is your first time voting in Illinois. (See [What forms of identification do I need to register to vote?](#item-voter-id-to-register))
