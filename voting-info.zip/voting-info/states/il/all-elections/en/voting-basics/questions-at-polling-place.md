---
title: "What if I have questions at the polling place?"
published: true
weight: 2
section: "voting-basics"
priority: "Minor"
---
Every Illinois voter is entitled to receive instruction on how to cast their vote from election judges, trained election workers who are there to help you navigate the voting process. If you have questions after you arrive at the polling place, they will be happy to help you.  
