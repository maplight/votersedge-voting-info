---
title: "Can I vote if I have been convicted of a crime?"
published: true
weight: 5
section: "my-rights-as-a-voter"
priority: "Minor"
---
**What are my voting rights if I have been convicted of a misdemeanor?**  

**Your voting rights are not affected by any misdemeanor conviction.** You can vote in all Illinois elections without restriction due to your criminal record.  

**What are my voting rights if I have been convicted of a felony?**  

**If you have a felony conviction and are currently incarcerated, you are not eligible to vote.** Your voting rights will be restored when you are released from prison. You will be eligible to vote even if you are on parole or probation; however, you must re-register to vote after your release.  
