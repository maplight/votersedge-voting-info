---
title: "What are my rights if I need language assistance?"
published: true
weight: 3
section: "my-rights-as-a-voter"
priority: "Minor"
---
Voters in jurisdictions with a statutorily-specified minimum number of voters who speak a primary language other than English may be entitled to receive a written ballot or other election materials or assistance in a language other than English in some areas of Illinois.  
