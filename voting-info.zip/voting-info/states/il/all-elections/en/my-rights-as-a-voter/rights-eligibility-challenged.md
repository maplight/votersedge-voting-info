---
title: What are my rights as a voter whose eligibility is challenged?
published: true
weight: 4
section: "my-rights-as-a-voter"
priority: "Minor"
---
If your name is missing from the list of registered voters in your precinct, or if the election judge challenges your eligibility to vote for any reason, you are entitled to cast a provisional ballot. (See [What is a provisional ballot?](#item-what-is-provisional-ballot))  
