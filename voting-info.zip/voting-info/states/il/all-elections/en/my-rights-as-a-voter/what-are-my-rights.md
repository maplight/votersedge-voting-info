---
title: "What are my rights as an Illinois voter?"
published: true
weight: 1
section: "my-rights-as-a-voter"
priority: "Minor"
---

**As a voter in the state of Illinois, you have certain rights** guaranteed by state and federal law. Please see this [voter information publication](http://www.elections.state.il.us/downloads/votinginformation/pdf/illinois_voter_information.pdf) from the Illinois State Election Authority for a full list of your voter rights.
