---
title: "How do I return my vote-by-mail ballot?"
published: true
weight: 3
section: "ways-to-vote"
priority: "Minor"
---
**You may vote by mail starting 40 days prior to Election Day** by sending your completed vote-by-mail ballot to your [local election authority](http://www.elections.il.gov/ElectionAuthorities/ElecAuthorityList.aspx). Please note the following before sending your ballot:  
- You must sign the affidavit on the ballot envelope.  
- Your ballot must be placed into the certification envelope provided with your ballot.  
- The certification on the envelope must be completed and signed.  
- The envelope must be sealed.  
- Mailed ballots must be postmarked no later than Election Day and received no later than 14 days after the election to be counted.  
- If you receive assistance in completing your ballot, the name and address of the individual who provided assistance must be included on the certification envelope.  

**You may also return your vote-by-mail ballot in person** to the election authority up to 40 days prior to the election or on Election Day. You may authorize any person to return your ballot for you by signing the affidavit on the ballot envelope affirming that you gave this person authorization to deliver your ballot for you.  


