---
title: "How do I vote at the polling place in person in Fresno County?"
published: true
weight: 6
section: "ways-to-vote"
priority: Minor
---
Find your polling place:  
Look on the **back cover of your Sample Ballot** for the address  

**-OR-** Use the [My Polling Place](#section-my-polling-place) section of this site.  
 
**-OR- Call** (559) 600-8683 for information  

For specific information with photos and Spanish translation scroll to [“Help for the New Voter.”](http://www.co.fresno.ca.us/uploadedFiles/Departments/County_Clerk_Registrar_of_Voters/PDF/NewVoterHelp.pdf)  
