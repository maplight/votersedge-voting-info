---
title: "How do I return my vote-by-mail ballot in Fresno County?"
published: true
weight: 4
section: "ways-to-vote"
priority: Minor
---
**Mail it** to the Fresno County Clerk/Registrar of Voters.  
	**Follow the directions** on the special return envelope.  
    If you mail your ballot, **don’t delay.** **Be sure to mail it so that it is postmarked before or on Election Day.**  

**-OR- Drop it off** at any polling place in Fresno County on Election Day.  

**-OR- Drop it off** at the Fresno County Clerk/Registrar of Voters office.  
	2221 Kern Street  
    Fresno, CA 93721
