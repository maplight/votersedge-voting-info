---
title: "How do I vote early in person in Fresno County?"
published: true
weight: 5
section: "ways-to-vote"
priority: Minor
---
**You can vote early in person starting 29 days before Election Day.**  

**Monday-Friday 8:30 AM to 5 PM**  

**Early voting location:** Fresno County Clerk/Registrar of Voters 2221 Kern Street Fresno, CA 93721
