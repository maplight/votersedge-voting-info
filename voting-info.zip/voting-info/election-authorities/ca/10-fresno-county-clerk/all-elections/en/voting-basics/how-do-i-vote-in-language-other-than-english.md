---
title: "How do I vote if I speak a language other than English in Fresno County?"
published: true
weight: 9
section: voting-basics
priority: Minor
---
The Fresno County Clerk/Registrar of Voters offers the [Application for Vote-by-Mail Ballot](http://www.co.fresno.ca.us/uploadedFiles/Departments/County_Clerk_Registrar_of_Voters/PDF/VotebyMailEnglish-Spanish.pdf) and Sample Ballots in Spanish.  

Some polling places offer ballot in Chinese, Japanese, Hindi, and Khmer.  
Contact the Fresno County Elections Office at (559) 600-8683 for specific details on languages available at your polling place.  
