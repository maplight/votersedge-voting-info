---
title: "How do I vote if I have disabilities in Fresno County?"
published: true
weight: 8
section: voting-basics
priority: Minor
---
Call (559) 600-8683 for specific questions about Fresno County.  
