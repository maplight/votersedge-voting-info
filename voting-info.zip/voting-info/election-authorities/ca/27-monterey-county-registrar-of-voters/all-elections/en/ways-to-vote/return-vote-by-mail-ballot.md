---
title: "How do I return my vote by mail ballot"
published: false
weight: 2
section: ways-to-vote
priority: "Minor"
---
