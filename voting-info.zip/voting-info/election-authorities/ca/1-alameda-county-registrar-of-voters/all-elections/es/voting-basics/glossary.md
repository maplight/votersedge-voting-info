---
title: "Glossary of words you need to know"
published: true
weight: 0
section: voting-basics
priority: Minor
---
