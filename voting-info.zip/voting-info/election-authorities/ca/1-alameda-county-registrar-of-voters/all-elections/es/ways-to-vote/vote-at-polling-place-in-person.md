---
title: "How Do I Vote at the Polling Place In Person?"
published: true
weight: 3
section: ways-to-vote
priority: Minor
---
Polls are open on Election Day from 7am to 8pm.

If you provided your voting address, then your polling location is printed here in the “Where do I vote?” section above.

Or, you can contact your <a href="#election-office-">County Elections Office</a> to find your polling place. 
