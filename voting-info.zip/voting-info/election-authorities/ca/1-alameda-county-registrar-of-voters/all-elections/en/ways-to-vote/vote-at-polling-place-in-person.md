---
title: "How do I vote at the polling place in person in Alameda County?"
published: true
weight: 6
section: "ways-to-vote"
priority: Minor
---
Find your polling place:  
- In the [My Polling Place](#section-my-polling-place) section of this site.
- On the [Alameda Elections Office](https://www.acgov.org/alco_ssl_app/rov/voter_info/voter_profile.jsp?formLanguage=E) website
- By calling the 24-hour hotline: (510) 267-8683

