---
title: "How do I get a vote-by-mail ballot?"
published: true
weight: 3
section: "ways-to-vote"
priority: Minor
---
Request a one-time vote by mail ballot  

- [Apply online](https://www.acgov.org/rov/votebymail.htm)  

- Call (510) 272-6973 to request a ballot to be mailed to you  

- [E-mail](https://www.acgov.org/form_app/feedback/feedback.jsp?id=ROVvbm), Fax, or mail us a letter requesting a vote-by-mail ballot and include your name, home address, the address to which you want the ballot mailed, and your signature.  

Or [become a permanent vote-by-mail voter](https://www.acgov.org/rov/votebymail.htm).

