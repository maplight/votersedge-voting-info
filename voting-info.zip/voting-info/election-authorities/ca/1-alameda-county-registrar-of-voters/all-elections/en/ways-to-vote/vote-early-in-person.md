---
title: "How do I vote early in person in Alameda County?"
published: true
weight: 5
section: "ways-to-vote"
priority: Minor
---
**You can vote in person before Election Day from 29 days before Election Day through the day before Election Day.** 

**Monday through Friday** 8:30 a.m. to 5 p.m.  

**Saturday and Sunday** 9 a.m. to 3 p.m.  

**Early voting location:** René C. Davidson Courthouse 1225 Fallon Street Room G-1 Oakland, CA 94612. [Get Map](https://www.google.com/maps/place/Ren%C3%A9+C.+Davidson+Courthouse,+1225+Fallon+St,+Oakland,+CA+94612/@37.7998255,-122.2651863,17z/data=!3m1!4b1!4m2!3m1!1s0x808f8735733618c5:0xbc91ceec51f24ea3)  
