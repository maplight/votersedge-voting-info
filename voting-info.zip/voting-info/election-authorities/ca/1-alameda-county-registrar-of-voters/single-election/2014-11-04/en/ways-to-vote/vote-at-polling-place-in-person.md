---
title: "How Do I Vote at the Polling Place In Person?"
published: true
weight: 3
section: how-to-vote
priority: Minor
---

h3 Vote at the polling place in person
  p.
    Polls are open on Election Day from 7am to 8pm.
  p.
    If you provided your voting address, then your polling location is printed here in the “Where do I vote?” section above.
  p.
    Or, you can contact your <a href="#election-office-">County Elections Office</a> to find your polling place. 
