---
title: "How Do I Vote Early In Person?"
published: false
weight: 2
section: ways-to-vote
priority: Minor
---
You may vote in person either at your County Elections Office or at another early voting location before Election Day. 

There may be early voting on the weekend which could be more convenient for you.  Check below for locations and hours of early voting locations in your county. 
