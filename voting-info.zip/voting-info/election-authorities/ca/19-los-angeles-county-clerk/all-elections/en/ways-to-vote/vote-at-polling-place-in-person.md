---
title: "How do I vote at the polling place in person in LA County?"
published: true
weight: 6
section: "ways-to-vote"
priority: Minor
---

Find your polling place:  

In the [My Polling Place](#section-my-polling-place) section of this site.  

**-OR-** On the Los Angeles County Registrar-Recorder/County Clerk [polling place locator](https://www.lavote.net/locator/)  

**-OR-** in your [E-Sample ballot link](https://www.lavote.net/home/voting-elections/voting-options/e-sample-ballot) if you subscribe to the service  

**-OR-** on the back of your Sample Ballot.  
