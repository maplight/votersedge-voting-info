---
title: "How do I vote early in person in LA County?"
published: true
weight: 5
section: "ways-to-vote"
priority: Minor
---

[You can vote in person](https://www.lavote.net/home/voting-elections/voting-options/early-voting) before Election Day from Monday, March 14 through Monday, April 12.  

Contact the Norwalk office at 1(800) 815-2666 or (562) 466-1323 to confirm business hours.  

**Early voting location:**  
	12400 Imperial Hwy.  
    Third Floor, Room 3002  
    Norwalk, CA 90650  
